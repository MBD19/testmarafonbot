# Sherzpd_Rustamov_uchun_marafon_bot
Ushbu botda pyTelegramBotAPI kutubxonasi va SQLite ma'lumotlar bazasidan foydalanildi.

Foydalanish:

sizda telebot kutubxonasi o'rnatilgan bo'lishi kerak.

"YOUR_BOT_TOKEN" ichiga @botfather dan olgan tokeningizni joylaysiz

"Your_channel" ichiga @ yoki https://T.me larsiz kanal manzilining o'zini yozasiz.

"Admin_id" ichiga admin ID raqamini yozasiz.
